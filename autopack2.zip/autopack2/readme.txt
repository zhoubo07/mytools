## 使用方法
1. studio中打包，生成的apk进行360加固（注：只要加固不要签名）
2. 在channel文件设置渠道配置,在config.ini文件配置应用签名（这里第一行留一行空白）
3. 将加固过的apk文件拖到autopacktoolsteps.exe上
4. packtool将自动打包签名，生成的渠道文件在/build/apks中

## 项目说明
~~~
/lib  处理所使用的工具
channel 渠道配置文件
config.ini 签名配置文件
autopacktoolsteps.exe 执行文件（显示步骤）
autopacktoolnostep.exe 执行文件（不显示步骤）
~~~

